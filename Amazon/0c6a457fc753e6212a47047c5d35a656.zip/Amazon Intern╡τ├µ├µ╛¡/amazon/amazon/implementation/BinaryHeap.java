public class BinaryHeap<E extends Comparable<E>>{
	private static final int DEFAULT_SIZE = 10;
	private int currentSize;
	private E[] array;


	public BinaryHeap(){

	}

	public BinaryHeap(int capacity){

	}

	public BinaryHeap(E[] items){

	}

	public void insert(E x){

	}

	public E findMin(){

	}

	public E deleteMin(){

	}

	public boolean isEmpty(){

	}

	public void makeEmpty(){

	}

	private void heapifyDown(int hole){

	}

	private void buildHeap(){

	}

	private void enlargeArray(int newSize){
		
	}
}