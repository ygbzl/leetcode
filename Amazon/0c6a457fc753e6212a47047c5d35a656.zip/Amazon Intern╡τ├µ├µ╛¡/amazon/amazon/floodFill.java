
// Write a function to “flood fill” a bitmap, function should allow controlling level of flood fill.

// A[5][5] of integers where each cell can have only 0/1. If it's 0, its not flodded yet, if it's 1, its already flooded.

// water at point p at time t1,
// p, p's neighbors at time t2 (t1+x). 1point 3acres 璁哄潧
// p, p's neighbors, p's neighbors' neighbors -> at time t3 (t2+x) 
// current cell (i, j) => i-1, j or i, j+1, or i, j-1, or i+1, j  or i+1, j+1 or i-1, j-1

// input: 2d array(filled, but ), starting cell (i, j), level of flooding (1,2,3....) 

public class floodFill{
	public static void main(String[] args){

	}

	public static void flood(int[][] board, int startX, int startY, int level){
		
	}
}