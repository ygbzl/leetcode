//serialize and deserialize a tree
