//find next node by next = delete.next;
//find prev node by using while loop
//while(iter.next != delete)
//    iter = iter.next;